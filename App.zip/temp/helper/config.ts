const BASE_URL = 'https://api.github.com/';

export const URLS = {
  GET_USERS: BASE_URL + 'users',
};
