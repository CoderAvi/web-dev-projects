# Interactive Dictionary

## About

This is an interactive dictionary which gives definition of words inputted by the user

## Modules included

**json**

Python has a built-in package called json, which can be used to work with JSON data.

**difflib**

The difflib module contains tools for computing and working with differences between sequences. It is especially useful for comparing text, and includes functions that produce reports using several common difference formats.