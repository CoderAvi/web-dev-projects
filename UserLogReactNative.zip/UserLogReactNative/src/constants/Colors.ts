export default {
  WHITE: '#FFFFFF',
  BLACK: '#000000',
  HEADER_BACKGROUND: '#1e2749',
  BTN_BACKGROUND: '#800000',
  PRIMARY: {
    BODY: '#fafaff',
    NOT_SELECTED: '#f9e9ec',
    SELECTED: '#e4d9ff',
  },
};
