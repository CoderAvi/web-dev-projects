import { View, Text } from 'react-native'
import React from 'react'

export default function CustomSearchBar() {
  return (
	<View>
	  <Text>CustomSearchBar</Text>
	</View>
  )
}