
import Nav from '../../components/Nav';

export default function Shop() {
	return (
		<div>
			<Nav />
			<h1 style={{ color: '#000' }}>Shop</h1>
		</div>
	);
}
